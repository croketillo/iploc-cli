#IPLOC v1.1

IPLOC es un geolocalizador de IPś en la terminal.


##USE

$iploc <IP TARGET> 




