# IPLOC v1.0

IPLOC is a CLI geolocartor IP.


## INSTALL

```git clone https://github.com/croketillo/iploc-cli.git```

```cd deb ```

```sudo dkpg -i python3-iploc python3-iploc_1.0-1_all.deb ```

## USE

```iploc <IP TARGET> ```







